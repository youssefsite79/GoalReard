export type RewardType = 'text' | 'image';
export type GoalMode = 'timer' | 'qr';

export interface Goal {
  id: string;
  userId: string;
  name: string;
  mode?: GoalMode; // optional for backwards compatibility
  deadline: number; // timestamp in milliseconds
  qrCodeData?: string; // the string encoded in the QR code (if mode === 'qr')
  qrUnlocked?: boolean; // whether the user successfully scanned the QR
  rewardType: RewardType;
  rewardContent: string; // text or base64 data URI
  createdAt: number;
}
