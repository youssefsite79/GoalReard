import { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, setDoc, deleteDoc, orderBy, serverTimestamp, writeBatch, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Goal } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, userId: string | undefined) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: userId || null,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function useGoals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user, loading: authLoading } = useAuth();

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setGoals([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const q = query(
      collection(db, 'goals'),
      where('userId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedGoals = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Goal[];
      
      // Sort in memory mostly since we might want multiple things, but we can do it locally easily
      fetchedGoals.sort((a, b) => b.createdAt - a.createdAt);
      setGoals(fetchedGoals);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'goals', user.uid);
    });

    return () => unsubscribe();
  }, [user, authLoading]);

  const addGoal = async (goalSeed: Omit<Goal, 'id' | 'createdAt' | 'userId'>) => {
    if (!user) return;
    
    // We create our own ID so we can reuse logic, or let Firestore do it.
    const newDocRef = doc(collection(db, 'goals'));
    const newGoal: Goal = {
      ...goalSeed,
      id: newDocRef.id,
      userId: user.uid,
      createdAt: Date.now(),
    };

    try {
      await setDoc(newDocRef, newGoal);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `goals/${newDocRef.id}`, user.uid);
    }
  };

  const updateGoal = async (id: string, updates: Partial<Goal>) => {
    if (!user) return;
    try {
      const docRef = doc(db, 'goals', id);
      await updateDoc(docRef, updates);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `goals/${id}`, user.uid);
    }
  };

  const deleteGoal = async (id: string) => {
    if (!user) return;
    try {
      const docRef = doc(db, 'goals', id);
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `goals/${id}`, user.uid);
    }
  };

  return { goals, isLoading: isLoading || authLoading, addGoal, updateGoal, deleteGoal };
}
