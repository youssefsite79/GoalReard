import * as React from "react"
import { cn } from "@/src/lib/utils"

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', ...props }, ref) => {
    const baseStyles = "inline-flex items-center justify-center font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF3B3B] disabled:pointer-events-none disabled:opacity-50 tracking-widest uppercase border border-transparent"
    
    const variants = {
      primary: "bg-[#FF3B3B] text-black font-black hover:bg-white hover:text-black",
      secondary: "bg-[#1a1a1a] text-[#F2F2F2] hover:bg-[#333] border-[#333]",
      outline: "border border-[#333] bg-transparent hover:border-[#FF3B3B] text-[#F2F2F2]",
      ghost: "hover:bg-[#1a1a1a] hover:text-[#FF3B3B] text-[#F2F2F2]",
      danger: "bg-[#444] text-[#F2F2F2] hover:bg-[#FF3B3B] hover:text-black"
    }

    const sizes = {
      sm: "h-9 px-4 text-[10px]",
      md: "h-12 px-6 py-2 text-xs",
      lg: "h-16 px-10 text-sm",
    }

    return (
      <button
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }
