import * as React from "react"
import { cn } from "@/src/lib/utils"

export type InputProps = React.InputHTMLAttributes<HTMLInputElement>

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex w-full bg-transparent border-0 border-b border-[#333] py-3 text-xl focus:outline-none focus:border-[#FF3B3B] transition-colors placeholder:opacity-20 disabled:cursor-not-allowed disabled:opacity-50 rounded-none file:border-0 file:bg-transparent file:text-sm file:font-medium",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
