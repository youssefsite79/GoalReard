import React, { useState, useRef } from 'react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { X, Upload, Image as ImageIcon, Type, Clock, Camera, QrCode } from 'lucide-react';
import { Goal, GoalMode, RewardType } from '../types';
import { QRScanner } from './QRScanner';
import { PhotoCapture } from './PhotoCapture';

interface CreateGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
}

export function CreateGoalModal({ isOpen, onClose, onSave }: CreateGoalModalProps) {
  const [name, setName] = useState('');
  const [mode, setMode] = useState<GoalMode>('timer');
  const [qrCodeData, setQrCodeData] = useState<string>('');
  const [showScanner, setShowScanner] = useState(false);
  const [showPhotoCapture, setShowPhotoCapture] = useState(false);
  
  const [durationMode, setDurationMode] = useState<'duration' | 'exact'>('duration');
  const [durationHours, setDurationHours] = useState('24');
  const [durationMinutes, setDurationMinutes] = useState('0');
  const [deadlineDate, setDeadlineDate] = useState('');
  const [rewardType, setRewardType] = useState<RewardType>('text');
  const [rewardText, setRewardText] = useState('');
  const [rewardImage, setRewardImage] = useState<string>('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setRewardImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    if (rewardType === 'text' && !rewardText) return;
    if (rewardType === 'image' && !rewardImage) return;

    if (mode === 'qr' && !qrCodeData) {
      alert("Please scan a QR code to bind.");
      return;
    }

    let deadlineTimestamp: number;

    if (durationMode === 'exact') {
      if (!deadlineDate) return;
      deadlineTimestamp = new Date(deadlineDate).getTime();
    } else {
      const h = parseInt(durationHours || '0');
      const m = parseInt(durationMinutes || '0');
      if (isNaN(h) || isNaN(m) || (h <= 0 && m <= 0)) {
        alert("Please enter a valid duration.");
        return;
      }
      const ms = (h * 60 * 60 * 1000) + (m * 60 * 1000);
      deadlineTimestamp = Date.now() + ms;
    }

    if (isNaN(deadlineTimestamp) || deadlineTimestamp <= Date.now()) {
      alert("Please select a future date and time.");
      return;
    }

    onSave({
      name,
      mode,
      qrCodeData: mode === 'qr' ? qrCodeData : undefined,
      qrUnlocked: false,
      deadline: deadlineTimestamp,
      rewardType,
      rewardContent: rewardType === 'text' ? rewardText : rewardImage,
    });

    // Reset form
    setName('');
    setMode('timer');
    setQrCodeData('');
    setDeadlineDate('');
    setRewardType('text');
    setRewardText('');
    setRewardImage('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#0D0D0D] border border-[#2A2A2A] w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-10 mt-10 mb-8 flex flex-col">
          <div className="text-[10px] tracking-[0.3em] uppercase opacity-50 mb-2 font-bold italic">System // Accountability</div>
          <h2 className="text-3xl font-black leading-[0.85] tracking-tighter uppercase">New<br/>Lockdown</h2>
          <Button variant="ghost" size="sm" onClick={onClose} className="absolute top-4 right-4 h-8 w-8 p-0 rounded-full border border-transparent hover:border-[#FF3B3B]">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="px-10 pb-10 overflow-y-auto">
          <form id="create-goal-form" onSubmit={handleSubmit} className="space-y-8">
            <div className="group">
              <label className="block text-[11px] uppercase tracking-widest text-[#FF3B3B] mb-2 font-bold">01. Protocol Mode</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMode('timer')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 text-xs uppercase tracking-widest font-bold transition-colors ${
                    mode === 'timer' ? 'bg-[#FF3B3B] text-black' : 'border border-[#333] text-[#F2F2F2] hover:border-[#FF3B3B]'
                  }`}
                >
                  <Clock className="w-4 h-4" /> Time Lock
                </button>
                <button
                  type="button"
                  onClick={() => setMode('qr')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 text-xs uppercase tracking-widest font-bold transition-colors ${
                    mode === 'qr' ? 'bg-[#FF3B3B] text-black' : 'border border-[#333] text-[#F2F2F2] hover:border-[#FF3B3B]'
                  }`}
                >
                  <QrCode className="w-4 h-4" /> QR Hunt
                </button>
              </div>
            </div>

            {mode === 'qr' && (
              <div className="group">
                <label className="block text-[11px] uppercase tracking-widest text-[#FF3B3B] mb-2 font-bold">01.5. Bind Target QR Code</label>
                {!qrCodeData ? (
                  <button 
                    type="button"
                    onClick={() => setShowScanner(true)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-4 border border-dashed border-[#FF3B3B] text-[#FF3B3B] hover:bg-[#FF3B3B]/10 transition-colors uppercase tracking-widest font-bold text-xs"
                  >
                    <Camera className="w-4 h-4" /> Scan Code to Bind
                  </button>
                ) : (
                  <div className="flex items-center justify-between p-4 border border-green-500/50 bg-green-500/10">
                    <div className="flex items-center gap-3">
                      <QrCode className="w-5 h-5 text-green-500" />
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-green-500 font-bold">QR BOUND</div>
                        <div className="text-xs font-mono text-[#F2F2F2] opacity-80 mt-1 truncate max-w-[200px]">{qrCodeData}</div>
                      </div>
                    </div>
                    <button type="button" onClick={() => setQrCodeData('')} className="text-[#F2F2F2] opacity-50 hover:opacity-100 uppercase text-[9px] tracking-widest underline">Reset</button>
                  </div>
                )}
              </div>
            )}

            <div className="group">
              <label className="block text-[11px] uppercase tracking-widest text-[#FF3B3B] mb-2 font-bold">02. Your Objective</label>
              <Input
                autoFocus
                placeholder="e.g., Finish the report, Read 20 pages"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="group">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-[11px] uppercase tracking-widest text-[#FF3B3B] font-bold">03. The Quarantine Duration</label>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setDurationMode('duration')} className={`text-[9px] uppercase tracking-widest px-2 py-1 border transition-colors ${durationMode === 'duration' ? 'border-[#FF3B3B] text-[#FF3B3B]' : 'border-[#333] text-[#333] hover:border-[#F2F2F2] hover:text-[#F2F2F2]'}`}>Amount</button>
                  <button type="button" onClick={() => setDurationMode('exact')} className={`text-[9px] uppercase tracking-widest px-2 py-1 border transition-colors ${durationMode === 'exact' ? 'border-[#FF3B3B] text-[#FF3B3B]' : 'border-[#333] text-[#333] hover:border-[#F2F2F2] hover:text-[#F2F2F2]'}`}>Exact</button>
                </div>
              </div>

              {durationMode === 'duration' ? (
                <div className="flex items-end gap-6">
                  <div className="flex items-end gap-2">
                    <input 
                      type="number" 
                      min="0"
                      placeholder="24"
                      className="w-16 bg-transparent border-0 border-b border-[#333] py-2 text-4xl font-mono focus:outline-none focus:border-[#FF3B3B] text-[#F2F2F2] transition-colors placeholder:opacity-20 text-center"
                      value={durationHours}
                      onChange={(e) => setDurationHours(e.target.value)}
                    />
                    <div className="text-lg opacity-40 mb-2 lowercase italic tracking-widest text-[#444]">hrs</div>
                  </div>
                  <div className="flex items-end gap-2">
                    <input 
                      type="number" 
                      min="0"
                      max="59"
                      placeholder="0"
                      className="w-16 bg-transparent border-0 border-b border-[#333] py-2 text-4xl font-mono focus:outline-none focus:border-[#FF3B3B] text-[#F2F2F2] transition-colors placeholder:opacity-20 text-center"
                      value={durationMinutes}
                      onChange={(e) => setDurationMinutes(e.target.value)}
                    />
                    <div className="text-lg opacity-40 mb-2 lowercase italic tracking-widest text-[#444]">mins</div>
                  </div>
                </div>
              ) : (
                <Input
                  type="datetime-local"
                  value={deadlineDate}
                  onChange={(e) => setDeadlineDate(e.target.value)}
                  className="w-full"
                  required
                />
              )}
            </div>

            <div className="space-y-4">
              <label className="block text-[11px] uppercase tracking-widest text-[#FF3B3B] mb-2 font-bold">04. The Prize</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRewardType('text')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 text-xs uppercase tracking-widest font-bold transition-colors ${
                    rewardType === 'text' ? 'bg-[#FF3B3B] text-black' : 'border border-[#333] text-[#F2F2F2] hover:border-[#FF3B3B]'
                  }`}
                >
                  <Type className="w-4 h-4" /> Text
                </button>
                <button
                  type="button"
                  onClick={() => setRewardType('image')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 text-xs uppercase tracking-widest font-bold transition-colors ${
                    rewardType === 'image' ? 'bg-[#FF3B3B] text-black' : 'border border-[#333] text-[#F2F2F2] hover:border-[#FF3B3B]'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" /> Image
                </button>
              </div>

              {rewardType === 'text' ? (
                <textarea
                  className="w-full h-32 bg-transparent border border-[#333] px-4 py-3 text-sm focus:outline-none focus:border-[#FF3B3B] transition-colors placeholder:opacity-20 resize-none font-mono"
                  placeholder="A secret message, a link to a fun video, or a promise to yourself..."
                  value={rewardText}
                  onChange={(e) => setRewardText(e.target.value)}
                  required
                />
              ) : (
                <div 
                  className={`border-2 border-dashed p-6 flex flex-col items-center justify-center gap-4 transition-colors group ${rewardImage ? 'border-[#FF3B3B]' : 'border-[#333] hover:border-[#FF3B3B]'}`}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                  {rewardImage ? (
                    <div className="relative w-full h-48 bg-black">
                      <img src={rewardImage} alt="Reward preview" className="w-full h-full object-contain" />
                      <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex items-end justify-center gap-4">
                        <button type="button" onClick={() => fileInputRef.current?.click()} className="text-[#FF3B3B] text-xs font-bold uppercase py-2 px-3 border border-[#FF3B3B] bg-black/80 hover:bg-[#FF3B3B] hover:text-black transition-colors">File</button>
                        <button type="button" onClick={() => setShowPhotoCapture(true)} className="text-[#FF3B3B] text-xs font-bold uppercase py-2 px-3 border border-[#FF3B3B] bg-black/80 hover:bg-[#FF3B3B] hover:text-black transition-colors">Camera</button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-4 w-full">
                      <button 
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1 flex flex-col items-center justify-center border border-[#444] rounded-none py-8 px-2 hover:border-[#FF3B3B] hover:bg-[#FF3B3B]/10 transition-all group/btn"
                      >
                        <Upload className="w-6 h-6 mb-3 text-[#F2F2F2] group-hover/btn:text-[#FF3B3B]" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-[#F2F2F2] group-hover/btn:text-[#FF3B3B]">Upload</span>
                      </button>
                      <button 
                        type="button"
                        onClick={() => setShowPhotoCapture(true)}
                        className="flex-1 flex flex-col items-center justify-center border border-[#444] rounded-none py-8 px-2 hover:border-[#FF3B3B] hover:bg-[#FF3B3B]/10 transition-all group/btn"
                      >
                        <Camera className="w-6 h-6 mb-3 text-[#F2F2F2] group-hover/btn:text-[#FF3B3B]" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-[#F2F2F2] group-hover/btn:text-[#FF3B3B]">Take Photo</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <p className="text-[10px] opacity-40 italic flex items-center gap-2 border-t border-[#2A2A2A] pt-6">
              Reward isolation ensures neurochemical alignment. Locked upon initiation.
            </p>
          </form>
        </div>

        <div className="border-t border-[#2A2A2A] flex">
          <Button type="button" variant="ghost" onClick={onClose} className="flex-1 rounded-none border-r border-[#2A2A2A] h-16">Abort</Button>
          <Button type="submit" form="create-goal-form" className="flex-1 rounded-none h-16">Initiate Lockdown</Button>
        </div>
      </div>
      
      {showScanner && (
        <QRScanner 
          onScan={(data) => {
            setQrCodeData(data);
            setShowScanner(false);
          }}
          onClose={() => setShowScanner(false)}
        />
      )}
      
      {showPhotoCapture && (
        <PhotoCapture 
          onCapture={(dataUri) => {
            setRewardImage(dataUri);
            setShowPhotoCapture(false);
          }}
          onClose={() => setShowPhotoCapture(false)}
        />
      )}
    </div>
  );
}
