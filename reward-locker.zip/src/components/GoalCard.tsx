import React, { useState, useEffect } from 'react';
import { Goal } from '../types';
import { Lock, Unlock, Clock, Trash2, Image as ImageIcon, QrCode } from 'lucide-react';
import { Button } from './ui/Button';
import { QRScanner } from './QRScanner';

interface GoalCardProps {
  goal: Goal;
  onUpdate: (id: string, updates: Partial<Goal>) => void;
  onDelete: (id: string) => void;
}

export function GoalCard({ goal, onUpdate, onDelete }: GoalCardProps) {
  const [timeLeft, setTimeLeft] = useState(Math.max(0, goal.deadline - Date.now()));
  const [showScanner, setShowScanner] = useState(false);
  const [scanError, setScanError] = useState('');
  
  const isQrMode = goal.mode === 'qr';
  const isTimeUp = goal.deadline <= Date.now();
  
  // Timer mode unlocks when time is up. 
  // QR mode unlocks when qrUnlocked is true.
  const isUnlocked = isQrMode ? !!goal.qrUnlocked : isTimeUp;
  
  // QR Mode fails if time is up and it wasn't unlocked.
  const isFailed = isQrMode && isTimeUp && !goal.qrUnlocked;

  useEffect(() => {
    if (isUnlocked || isFailed) return;

    const interval = setInterval(() => {
      const remaining = goal.deadline - Date.now();
      if (remaining <= 0) {
        setTimeLeft(0);
        clearInterval(interval);
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [goal.deadline, isUnlocked, isFailed]);

  const formatTimeLeft = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0 || days > 0) parts.push(`${hours}h`);
    if (minutes > 0 || hours > 0 || days > 0) parts.push(`${minutes}m`);
    parts.push(`${seconds}s`);

    return parts.join(' ');
  };

  const handleScan = (data: string) => {
    if (data === goal.qrCodeData) {
      onUpdate(goal.id, { qrUnlocked: true });
      setShowScanner(false);
      setScanError('');
    } else {
      setScanError('Code mismatch. Access denied.');
      setTimeout(() => setScanError(''), 3000);
    }
  };

  return (
    <div className={`relative overflow-hidden group flex flex-col ${
      isUnlocked ? 'bg-[#111] border-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.15)]' : 
      isFailed ? 'bg-[#1a1a1a] border-red-500/50' :
      'bg-[#1a1a1a] border-[#333]'
    } border transition-all duration-500 min-h-[400px]`}>
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(#FF3B3B 0.5px, transparent 0.5px)', backgroundSize: '30px 30px' }}></div>

      <div className="relative z-10 flex flex-col h-full p-8 md:p-12">
        <div className="flex justify-between items-start mb-12">
          <div className="flex gap-4">
            <div className={`px-3 py-1 border text-[10px] uppercase font-bold tracking-widest ${
              isUnlocked ? 'border-green-500 text-green-500' : 
              isFailed ? 'border-red-500 text-red-500' :
              'border-[#FF3B3B] text-[#FF3B3B]'
            }`}>
              Status: {isUnlocked ? 'Compromised' : isFailed ? 'Failed' : 'Active'}
            </div>
            <div className="px-3 py-1 border border-[#333] text-white text-[10px] uppercase font-bold tracking-widest italic hidden sm:block">
              Locked: {new Date(goal.createdAt).toISOString().split('T')[0].replace(/-/g, '.')}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs opacity-40 uppercase tracking-widest">Vault Identity</div>
            <div className="font-mono text-xs tracking-tighter text-[#FF3B3B]">#{goal.id.substring(0, 8).toUpperCase()}</div>
          </div>
        </div>

        <div className="text-center mb-8">
          <h3 className="text-2xl sm:text-3xl font-black font-sans uppercase tracking-[0.1em] text-white mb-2">{goal.name}</h3>
        </div>

        <div className="flex-1 flex flex-col justify-center items-center">
          {!isUnlocked && !isFailed ? (
            <div className="relative w-full max-w-sm h-64 bg-[#111] border border-[#333] group-hover:border-[#FF3B3B]/50 transition-colors flex items-center justify-center overflow-hidden mx-auto">
              <div className="absolute inset-0 grayscale contrast-125 blur-3xl opacity-30 bg-center bg-cover" 
                   style={{ backgroundImage: "url('https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2070&auto=format&fit=crop')" }}></div>
              
              <div className="relative z-10 flex flex-col items-center">
                 <Lock className="w-12 h-12 text-[#FF3B3B] mb-4 opacity-80" />
                 <div className="text-2xl font-black tracking-[0.2em] uppercase text-white">Encrypted</div>
                 <div className="text-[10px] uppercase tracking-[0.5em] mt-2 text-[#FF3B3B] font-bold">Zero-Hour: {new Date(goal.deadline).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                 {isQrMode && (
                   <div className="mt-6 flex flex-col items-center">
                     <Button type="button" onClick={() => setShowScanner(true)} className="border border-[#FF3B3B] text-[#FF3B3B] bg-black/50 hover:bg-[#FF3B3B] hover:text-black">
                       <QrCode className="w-4 h-4 mr-2" /> Verify Code
                     </Button>
                     {scanError && <div className="text-[#FF3B3B] text-[10px] mt-2 uppercase font-bold tracking-widest">{scanError}</div>}
                   </div>
                 )}
              </div>

              <div className="absolute w-full h-[1px] bg-[#FF3B3B]/30 top-1/2 left-0 shadow-[0_0_15px_rgba(255,59,59,0.5)]"></div>
            </div>
          ) : isFailed ? (
            <div className="w-full max-w-sm mx-auto border border-red-500/50 bg-black relative animate-in fade-in zoom-in-95 duration-500 overflow-hidden min-h-[256px] flex flex-col items-center justify-center p-8 text-center">
              <Lock className="w-16 h-16 text-red-500 mb-6 opacity-80" />
              <div className="text-3xl font-black tracking-[0.2em] uppercase text-white">Locked</div>
              <div className="text-xs uppercase tracking-[0.2em] mt-2 text-red-500 font-bold max-w-[200px] leading-relaxed">
                Objective window closed. Access permanently denied.
              </div>
            </div>
          ) : (
            <div className="w-full max-w-sm mx-auto border border-green-500/50 bg-black relative animate-in fade-in zoom-in-95 duration-500 overflow-hidden">
               {goal.rewardType === 'text' ? (
                 <div className="p-8 text-center min-h-[256px] flex items-center justify-center">
                   <p className="text-lg font-mono text-green-500 whitespace-pre-wrap">{goal.rewardContent}</p>
                 </div>
               ) : (
                 <div className="relative group">
                    <img src={goal.rewardContent} alt="Reward" className="w-full h-64 object-contain bg-black/50" />
                 </div>
               )}
            </div>
          )}
        </div>

        {!isUnlocked && !isFailed && (
          <div className="mt-8">
            <div className="flex justify-center gap-4 sm:gap-8 pb-8 border-b border-[#2A2A2A]">
              <div className="text-center">
                <div className="text-4xl sm:text-5xl font-mono font-bold tabular-nums text-white">
                  {Math.floor(timeLeft / (1000 * 60 * 60 * 24)).toString().padStart(2, '0')}
                </div>
                <div className="text-[10px] uppercase tracking-widest opacity-40 mt-1">Days</div>
              </div>
              <div className="text-center">
                <div className="text-4xl sm:text-5xl font-mono font-bold tabular-nums text-[#FF3B3B]">
                  {Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)).toString().padStart(2, '0')}
                </div>
                <div className="text-[10px] uppercase tracking-widest opacity-40 mt-1">Hours</div>
              </div>
              <div className="text-center">
                <div className="text-4xl sm:text-5xl font-mono font-bold tabular-nums text-white">
                  {Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, '0')}
                </div>
                <div className="text-[10px] uppercase tracking-widest opacity-40 mt-1">Mins</div>
              </div>
              <div className="text-center">
                <div className="text-4xl sm:text-5xl font-mono font-bold tabular-nums text-[#FF3B3B]">
                  {Math.floor((timeLeft % (1000 * 60)) / 1000).toString().padStart(2, '0')}
                </div>
                <div className="text-[10px] uppercase tracking-widest opacity-40 mt-1">Secs</div>
              </div>
            </div>
          </div>
        )}

        <div className={`flex justify-between items-end pt-8 ${isUnlocked ? 'border-t border-[#2A2A2A] mt-8' : ''}`}>
          <Button variant="ghost" size="sm" onClick={() => onDelete(goal.id)} className="h-8 group-hover:opacity-100 sm:opacity-50 transition-opacity p-0 w-auto hover:bg-transparent">
            <Trash2 className="w-3.5 h-3.5 mr-2 opacity-50 text-white group-hover:text-[#FF3B3B]" /> <span className="opacity-50 uppercase tracking-widest text-[9px]">Purge</span>
          </Button>
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-20">
            Fortress Mode Enabled
          </div>
        </div>
      </div>
      
      {/* Corner Accents */}
      <div className="absolute top-0 right-0 p-4 border-b border-l border-[#2A2A2A] text-[9px] uppercase tracking-widest opacity-30 z-0 pointer-events-none">Terminal_01</div>
      <div className="absolute bottom-0 right-0 p-4 text-[9px] uppercase tracking-widest opacity-30 rotate-180 z-0 pointer-events-none" style={{ writingMode: 'vertical-rl' }}>24.12.052</div>
      
      {showScanner && (
        <QRScanner 
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
}
