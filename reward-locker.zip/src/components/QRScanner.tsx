import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, X } from 'lucide-react';
import { Button } from './ui/Button';

interface QRScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export function QRScanner({ onScan, onClose }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let animationFrameId: number;
    let stream: MediaStream | null = null;
    let isScanning = true;

    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true'); // required to tell iOS safari we don't want fullscreen
          videoRef.current.play();
          requestAnimationFrame(tick);
        }
      } catch (err) {
        setError('Could not access camera. Please ensure permissions are granted.');
      }
    };

    const tick = () => {
      if (!isScanning) return;
      if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        const canvasElement = canvasRef.current;
        const video = videoRef.current;
        if (canvasElement && video) {
          canvasElement.height = video.videoHeight;
          canvasElement.width = video.videoWidth;
          const canvas = canvasElement.getContext('2d', { willReadFrequently: true });
          if (canvas) {
            canvas.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
            const imageData = canvas.getImageData(0, 0, canvasElement.width, canvasElement.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
              inversionAttempts: 'dontInvert',
            });
            if (code && code.data) {
              isScanning = false;
              onScan(code.data);
              return; // Stop after scanning once
            }
          }
        }
      }
      animationFrameId = requestAnimationFrame(tick);
    };

    startCamera();

    return () => {
      isScanning = false;
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [onScan]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
      <div className="bg-[#0D0D0D] border border-[#2A2A2A] w-full max-w-md overflow-hidden flex flex-col items-center p-8 relative">
        <Button variant="ghost" size="sm" onClick={onClose} className="absolute top-4 right-4 h-8 w-8 p-0 rounded-full border border-transparent hover:border-[#FF3B3B] z-10 transition-colors">
            <X className="w-4 h-4 text-white" />
        </Button>

        <h3 className="text-xl font-black uppercase tracking-widest text-white mb-6 mt-4">Scan QR Code</h3>

        {error ? (
          <div className="text-[#FF3B3B] text-center text-sm p-4 border border-[#FF3B3B]/50 bg-[#FF3B3B]/10">{error}</div>
        ) : (
          <div className="relative w-full aspect-square border-2 border-[#FF3B3B] overflow-hidden bg-black flex items-center justify-center group">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+PHBhdGggZD0iTTAgMGgyMHYyMEgweiIgZmlsbD0ibm9uZSIvPjxjaXJjbGUgY3g9IjIiIGN5PSIyIiByPSIyIiBmaWxsPSJyZ2JhKDI1NSwgNTksIDU5LCAwLjIpIi8+PC9zdmc+')] bg-[length:20px_20px] opacity-20 pointer-events-none z-10"></div>
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
            
            <div className="absolute inset-0 shadow-[inset_0_0_50px_rgba(0,0,0,0.8)] z-10 pointer-events-none"></div>
            
            {/* Scanner line */}
            <div className="absolute w-full h-[2px] bg-[#FF3B3B] shadow-[0_0_10px_#FF3B3B] top-1/2 left-0 z-20 animate-[scan_2s_ease-in-out_infinite_alternate]" style={{
                opacity: 0.8
            }}></div>
          </div>
        )}
        <p className="text-[10px] uppercase font-mono tracking-widest text-[#F2F2F2]/50 mt-6 text-center">Center the QR Code within the frame.</p>
      </div>
      <style>{`
        @keyframes scan {
            0% { transform: translateY(-100px); }
            100% { transform: translateY(100px); }
        }
      `}</style>
    </div>
  );
}
