import React, { useEffect, useRef, useState } from 'react';
import { Camera, X } from 'lucide-react';
import { Button } from './ui/Button';

interface PhotoCaptureProps {
  onCapture: (dataUri: string) => void;
  onClose: () => void;
}

export function PhotoCapture({ onCapture, onClose }: PhotoCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string>('');
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true'); // required to tell iOS safari we don't want fullscreen
          videoRef.current.play();
        }
      } catch (err) {
        setError('Could not access camera. Please ensure permissions are granted.');
      }
    };

    startCamera();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUri = canvas.toDataURL('image/jpeg', 0.9);
        onCapture(dataUri);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
      <div className="bg-[#0D0D0D] border border-[#2A2A2A] w-full max-w-md overflow-hidden flex flex-col items-center p-8 relative">
        <Button variant="ghost" size="sm" onClick={onClose} className="absolute top-4 right-4 h-8 w-8 p-0 rounded-full border border-transparent hover:border-[#FF3B3B] z-10 transition-colors">
            <X className="w-4 h-4 text-white" />
        </Button>

        <h3 className="text-xl font-black uppercase tracking-widest text-white mb-6 mt-4">Capture Target</h3>

        {error ? (
          <div className="text-[#FF3B3B] text-center text-sm p-4 border border-[#FF3B3B]/50 bg-[#FF3B3B]/10">{error}</div>
        ) : (
          <div className="relative w-full aspect-square border-2 border-[#FF3B3B] overflow-hidden bg-black flex items-center justify-center">
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
          </div>
        )}
        
        <div className="mt-8 mb-4 w-full flex justify-center">
          <Button onClick={handleCapture} className="w-16 h-16 rounded-full bg-white text-black hover:bg-[#FF3B3B] border-[4px] border-[#333] shadow-[0_0_0_4px_white] hover:shadow-[0_0_0_4px_#FF3B3B] p-0 flex items-center justify-center transition-all">
            <Camera className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  );
}
