import React, { useState } from 'react';
import { Plus, Target, Lock, Trophy } from 'lucide-react';
import { CreateGoalModal } from './components/CreateGoalModal';
import { GoalCard } from './components/GoalCard';
import { useGoals } from './hooks/useGoals';
import { Button } from './components/ui/Button';
import { useAuth } from './AuthContext';

export default function App() {
  const { user, loading, login, signup, logout } = useAuth();
  const { goals, isLoading, addGoal, updateGoal, deleteGoal } = useGoals();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [authError, setAuthError] = useState('');

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-zinc-200 border-t-zinc-900 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    const handleAuth = async (e: React.FormEvent) => {
      e.preventDefault();
      setAuthError('');
      try {
        if (isLoginMode) {
          await login(email, password);
        } else {
          await signup(email, password);
        }
      } catch (err: any) {
        setAuthError(err.message);
      }
    };

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden bg-[#0D0D0D]">
        <div className="absolute inset-0 opacity-10 pointer-events-none fixed z-0" 
             style={{ backgroundImage: 'radial-gradient(#FF3B3B 0.5px, transparent 0.5px)', backgroundSize: '30px 30px' }}></div>
        <div className="text-center z-10 max-w-md w-full border border-[#2A2A2A] bg-[#111] p-12">
          <div className="border border-[#FF3B3B] p-4 bg-[#FF3B3B]/10 w-16 h-16 mx-auto mb-8 flex items-center justify-center">
            <Lock className="w-8 h-8 text-[#FF3B3B]" />
          </div>
          <h2 className="text-3xl font-black uppercase tracking-[0.2em] mb-4 text-[#F2F2F2]">Vaulting The Reward</h2>
          <p className="text-[#888] font-mono text-xs uppercase tracking-widest mb-8">Authenticate to access protocol and encrypted payloads.</p>
          
          <form onSubmit={handleAuth} className="space-y-4 text-left">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#F2F2F2] mb-2 font-bold opacity-70">Operator Email</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-[#333] p-3 text-[#F2F2F2] text-sm focus:border-[#FF3B3B] focus:outline-none transition-colors"
                required
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#F2F2F2] mb-2 font-bold opacity-70">Passcode</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-[#333] p-3 text-[#F2F2F2] text-sm focus:border-[#FF3B3B] focus:outline-none transition-colors"
                required
              />
            </div>
            
            {authError && (
              <div className="text-[#FF3B3B] text-[10px] font-mono uppercase p-2 bg-[#FF3B3B]/10 border border-[#FF3B3B]/50">
                ERR: {authError}
              </div>
            )}
            
            <Button type="submit" className="w-full h-14 mt-4">
              {isLoginMode ? 'Access Vault' : 'Initialize Protocol'}
            </Button>
          </form>

          <button 
            type="button" 
            onClick={() => setIsLoginMode(!isLoginMode)}
            className="text-[10px] uppercase tracking-widest mt-8 text-[#F2F2F2] opacity-50 hover:opacity-100 transition-opacity underline underline-offset-4"
          >
            {isLoginMode ? 'Need clearance? Generate operator ID.' : 'Already have clearance? Authenticate.'}
          </button>
        </div>
      </div>
    );
  }

  const activeGoals = goals.filter(g => {
    if (g.mode === 'qr') {
      return g.deadline > Date.now() && !g.qrUnlocked;
    }
    return g.deadline > Date.now();
  });
  
  const completedGoals = goals.filter(g => {
    if (g.mode === 'qr') {
      return g.deadline <= Date.now() || !!g.qrUnlocked;
    }
    return g.deadline <= Date.now();
  });

  return (
    <div className="min-h-screen pb-24 overflow-hidden relative">
      <div className="absolute inset-0 opacity-10 pointer-events-none fixed z-0" 
           style={{ backgroundImage: 'radial-gradient(#FF3B3B 0.5px, transparent 0.5px)', backgroundSize: '30px 30px' }}></div>

      {/* Header */}
      <header className="border-b border-[#2A2A2A] sticky top-0 z-10 bg-[#0D0D0D] backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="border border-[#FF3B3B] p-2 bg-[#FF3B3B]/10">
              <Lock className="w-5 h-5 text-[#FF3B3B]" />
            </div>
            <div>
              <h1 className="text-xl font-black font-sans uppercase tracking-[0.2em] text-[#F2F2F2] leading-none text-left">Vaulting<br/>The Reward</h1>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="hidden sm:flex text-[#888] hover:text-[#FF3B3B]" onClick={logout}>
              Disconnect
            </Button>
            <Button onClick={() => setIsModalOpen(true)} className="hidden sm:flex">
              Initiate Lockdown
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12 relative z-10">
        {goals.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center max-w-2xl mx-auto">
            <div className="text-[10px] tracking-[0.3em] uppercase opacity-50 mb-8 font-bold italic">System // Standby</div>
            <h2 className="text-5xl sm:text-7xl font-black leading-[0.85] tracking-tighter mb-8 uppercase text-white">
              Awaiting<br/>Directives
            </h2>
            <p className="text-sm opacity-50 tracking-wide font-mono mb-12 max-w-lg leading-relaxed text-[#F2F2F2]">
              Reward isolation ensures neurochemical alignment. Designate a target, encrypt the payload, and commit to the lockdown.
            </p>
            <Button size="lg" onClick={() => setIsModalOpen(true)} className="w-full sm:w-auto">
              Initiate First Lockdown
            </Button>
          </div>
        ) : (
          <div className="space-y-24">
            {/* Active Goals */}
            {activeGoals.length > 0 && (
              <section>
                <div className="flex items-end gap-4 mb-8 border-b border-[#2A2A2A] pb-4">
                  <h2 className="text-sm font-black uppercase tracking-[0.3em] text-[#FF3B3B]">Encrypted Vaults</h2>
                  <span className="text-[10px] font-mono opacity-50 mb-1">[{activeGoals.length} ACTIVE]</span>
                </div>
                <div className="grid gap-12 sm:grid-cols-2">
                  {activeGoals.map(goal => (
                    <GoalCard key={goal.id} goal={goal} onUpdate={updateGoal} onDelete={deleteGoal} />
                  ))}
                </div>
              </section>
            )}

            {/* Completed Goals */}
            {completedGoals.length > 0 && (
              <section>
                <div className="flex items-end gap-4 mb-8 border-b border-[#2A2A2A] pb-4">
                  <h2 className="text-sm font-black uppercase tracking-[0.3em] text-white opacity-50">Compromised Vaults</h2>
                  <span className="text-[10px] font-mono opacity-50 mb-1">[{completedGoals.length} UNLOCKED]</span>
                </div>
                <div className="grid gap-12 sm:grid-cols-2">
                  {completedGoals.map(goal => (
                    <GoalCard key={goal.id} goal={goal} onUpdate={updateGoal} onDelete={deleteGoal} />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {/* Mobile FAB */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-4 sm:hidden z-20">
        <button
          onClick={logout}
          className="bg-[#2A2A2A] text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg self-end hover:bg-[#333] transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
        </button>

        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-[#FF3B3B] text-black w-16 h-16 flex items-center justify-center hover:bg-white transition-transform active:scale-95 shadow-[0_0_20px_rgba(255,59,59,0.3)]"
        >
          <Lock className="w-6 h-6" />
        </button>
      </div>

      <CreateGoalModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={(goal) => {
          addGoal(goal);
          setIsModalOpen(false);
        }}
      />
    </div>
  );
}
